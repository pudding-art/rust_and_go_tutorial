#!/bin/bash

tools/stoptestenv.sh
tools/starttestenv.sh $1
